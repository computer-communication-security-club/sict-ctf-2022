<?php
	function mash_nuuts_function(){
		echo "<style>body{text-align:center;margin-top:200px;font-size:40px;color:#00FF00;background-color:black;font-weight:bold;background-image:url(flag.gif);background-repeat: no-repeat;background-position:center;}</style>";
		echo "<br><br>";
		die("sictCTF{pr3gggg_r3pl@c33333}");
	}
?>
