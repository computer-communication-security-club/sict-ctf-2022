<!DOCTYPE html>
<meta charset="UTF-8">
<html>
<head>
	<title>Bru-Cipher</title>
<style>
	body{
		background-color:black;
		color:cyan;
		background-image: url("rider.png");
		background-color: black;
		background-repeat: no-repeat;
		background-size: cover;
		color:cyan;
		font-weight: bold;
		font-family: 'Brush Script MT', cursive;
	}
</style>
</head>
<body>
<h1 style="text-align:center; margin-top:50px;">Муундаг яваад бай залуу минь</h1>
</body>
</html>
