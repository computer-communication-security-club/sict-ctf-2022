<!DOCTYPE html>
<html>
<head>
   <title>link</title>
<link rel = "stylesheet" href="style.css">
 
</head>

<body>

<div class="msg" style="margin-bottom: 20px;">
<img src="ord.png"></img></div>

</body>
</html>


<div id="console">
</div>

<script type="text/javascript" src = "script.js"></script>